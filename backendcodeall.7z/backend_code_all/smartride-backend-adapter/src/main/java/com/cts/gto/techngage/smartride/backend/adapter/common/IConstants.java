package com.cts.gto.techngage.smartride.backend.adapter.common;

public interface IConstants {
	
	String GLOBAL_SMARTPHONE_REGISTRATION_CHANNEL = "GR_ch";

	String BOOKING_CHANNEL_GROUP = "BC_grp";
	
	String pubKey = "pub-c-d1fd173b-9659-49bb-bd2a-932dbb59b4ed";
	String subKey = "sub-c-98efdd80-aa19-11e5-bb8b-02ee2ddab7fe";
	
	String BACKEND_DEVICE_UUID = "backend";
}
