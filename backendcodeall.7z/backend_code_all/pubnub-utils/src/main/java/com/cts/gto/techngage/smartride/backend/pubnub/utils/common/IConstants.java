package com.cts.gto.techngage.smartride.backend.pubnub.utils.common;

public interface IConstants {

	int THRESHOLD_CHUNK_SIZE_KB = 30;
	
	int MAX_CHANNEL_COUNT = 20;
}
