package com.cts.gto.techngage.smartride.backend.dao.vo;

public class PassengerProfile {
	int psngr_id;
	String psngr_gmail;
	String fname;
	String lname;
	String email;
	String mobile_no;
	int wallet_amount;
	
	public int getPsngr_id() {
		return psngr_id;
	}
	public void setPsngr_id(int psngr_id) {
		this.psngr_id = psngr_id;
	}
	public String getPsngr_gmail() {
		return psngr_gmail;
	}
	public void setPsngr_gmail(String psngr_gmail) {
		this.psngr_gmail = psngr_gmail;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile_no() {
		return mobile_no;
	}
	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}
	public int getWallet_amount() {
		return wallet_amount;
	}
	public void setWallet_amount(int wallet_amount) {
		this.wallet_amount = wallet_amount;
	}
	
	
	

}
