package com.cts.gto.techngage.smartride.backend.dao.vo;

public class SmartStop {
	int stop_id;
	String stop_nm;
	String stop_lat;
	String stop_long;
	
	public int getStop_id() {
		return stop_id;
	}
	public void setStop_id(int stop_id) {
		this.stop_id = stop_id;
	}
	public String getStop_nm() {
		return stop_nm;
	}
	public void setStop_nm(String stop_nm) {
		this.stop_nm = stop_nm;
	}
	public String getStop_lat() {
		return stop_lat;
	}
	public void setStop_lat(String stop_lat) {
		this.stop_lat = stop_lat;
	}
	public String getStop_long() {
		return stop_long;
	}
	public void setStop_long(String stop_long) {
		this.stop_long = stop_long;
	}
		
		
	

}
