package com.cts.gto.techngage.smartride.backend.dao.vo;

public class PassengerPhone {
	int device_id;
	int psngr_id;
	String device_channel;
	
	public int getDevice_id() {
		return device_id;
	}
	public void setDevice_id(int device_id) {
		this.device_id = device_id;
	}
	public int getPsngr_id() {
		return psngr_id;
	}
	public void setPsngr_id(int psngr_id) {
		this.psngr_id = psngr_id;
	}
	public String getDevice_channel() {
		return device_channel;
	}
	public void setDevice_channel(String device_channel) {
		this.device_channel = device_channel;
	}
	
	

}
