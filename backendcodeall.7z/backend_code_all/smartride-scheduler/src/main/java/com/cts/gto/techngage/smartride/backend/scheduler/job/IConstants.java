package com.cts.gto.techngage.smartride.backend.scheduler.job;

public interface IConstants {

	int THRESHOLD_CHUNK_SIZE_KB = 30;
	
	int MAX_CHANNEL_COUNT = 20;
	
	String[] SQL_MON = new String[]
			{"JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"};
}
